#include "ti_msp_dl_config.h"
#include "bsp_tb6612.h"

//自定义延时（不精确）
void delay_ms(unsigned int ms) 
{
    unsigned int i, j;
    // 下面的嵌套循环的次数是根据主控频率和编译器生成的指令周期大致计算出来的，
    // 需要通过实际测试调整来达到所需的延时。
    for (i = 0; i < ms; i++) 
    {
        for (j = 0; j < 8000; j++) 
        {
            // 仅执行一个足够简单以致于可以预测其执行时间的操作
            __asm__("nop"); // "nop" 代表“无操作”，在大多数架构中，这会消耗一个或几个时钟周期
        }
    }
}     





//主函数
int main(void)
{
    SYSCFG_DL_init();
	
		DL_TimerA_startCounter(PWM_1_INST);//开始计数
    while (1) 
    {    
				A_control(500,1); //速度 方向
				B_control(300,0); //速度 方向
       
    }
} 



