################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/bsp_tb6612.c 

C_DEPS += \
./BSP/bsp_tb6612.d 

OBJS += \
./BSP/bsp_tb6612.o 

OBJS__QUOTED += \
"BSP\bsp_tb6612.o" 

C_DEPS__QUOTED += \
"BSP\bsp_tb6612.d" 

C_SRCS__QUOTED += \
"../BSP/bsp_tb6612.c" 


