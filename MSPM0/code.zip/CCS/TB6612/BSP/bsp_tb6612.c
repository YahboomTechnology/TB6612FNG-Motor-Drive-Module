#include "bsp_tb6612.h"




void A_control(uint16_t motor_speed,uint8_t dir)
{
	if(dir)
	{
		AIN1_OUT(0);
		AIN2_OUT(1);
	}
	else
	{
		AIN1_OUT(1);
		AIN2_OUT(0);
	}
	
	DL_TimerA_setCaptureCompareValue(PWM_1_INST, motor_speed, DL_TIMER_CC_0_INDEX);
		
}



void B_control(uint16_t motor_speed,uint8_t dir)
{
	if(dir)
	{
		BIN1_OUT(0);
		BIN2_OUT(1);
	}
	else
	{
		BIN1_OUT(1);
		BIN2_OUT(0);
	}
	
	DL_TimerA_setCaptureCompareValue(PWM_1_INST, motor_speed, DL_TIMER_CC_1_INDEX);
		
}