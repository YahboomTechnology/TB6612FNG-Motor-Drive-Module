#ifndef __BSP_TB6612_H_
#define __BSP_TB6612_H_

#include "ti_msp_dl_config.h"

//A��� A Motor
#define AIN1_OUT(X)  ( (X) ? (DL_GPIO_setPins(GPIO_1_PORT,GPIO_1_AIN1_PIN)) : (DL_GPIO_clearPins(GPIO_1_PORT,GPIO_1_AIN1_PIN)) )
#define AIN2_OUT(X)  ( (X) ? (DL_GPIO_setPins(GPIO_2_PORT,GPIO_2_AIN2_PIN)) : (DL_GPIO_clearPins(GPIO_2_PORT,GPIO_2_AIN2_PIN)) )

//B��� B Motor
#define BIN1_OUT(X)  ( (X) ? (DL_GPIO_setPins(GPIO_3_PORT,GPIO_3_BIN1_PIN)) : (DL_GPIO_clearPins(GPIO_3_PORT,GPIO_3_BIN1_PIN)) )
#define BIN2_OUT(X)  ( (X) ? (DL_GPIO_setPins(GPIO_4_PORT,GPIO_4_BIN4_PIN)) : (DL_GPIO_clearPins(GPIO_4_PORT,GPIO_4_BIN4_PIN)) )

void A_control(uint16_t motor_speed,uint8_t dir);
void B_control(uint16_t motor_speed,uint8_t dir);


#endif

